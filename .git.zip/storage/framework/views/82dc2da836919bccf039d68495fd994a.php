Hello <?php echo e($name); ?>,

<?php echo e($body); ?>


— Crediping
<?php /**PATH C:\Users\DELL\Desktop\room-color\whatsap-business\whatsapp-crm-backend\resources\views/emails/platform-announcement-text.blade.php ENDPATH**/ ?>