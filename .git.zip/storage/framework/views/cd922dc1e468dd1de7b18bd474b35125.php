Crediping verification code

Hello <?php echo e($name); ?>,

Your Crediping verification code is: <?php echo e($code); ?>


This code expires in <?php echo e($minutes); ?> minutes. If you did not create a Crediping account, you can ignore this email.
<?php /**PATH C:\Users\DELL\Desktop\room-color\whatsap-business\whatsapp-crm-backend\resources\views/emails/verify-otp-text.blade.php ENDPATH**/ ?>