Hello {{ $name }},

{{ $body }}

— Crediping
