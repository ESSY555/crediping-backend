<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\DELL\Desktop\room-color\whatsap-business\whatsapp-crm-backend\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>